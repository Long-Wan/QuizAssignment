var LoginModel = function() {
};

LoginModel.prototype = {
};