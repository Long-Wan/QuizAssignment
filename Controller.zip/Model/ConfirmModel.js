var ConfirmModel = function() {
};

ConfirmModel.prototype = {
};