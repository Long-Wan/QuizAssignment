var SignUpModel = function() {
};

SignUpModel.prototype = {
};