var AppController = function(model, view, auth) {
    this.model = model;
    this.view = view;
    this.auth = auth;
};

AppController.prototype = {
    init: function() {
    }
};